# branch_warehouse/admin.py
from django.contrib import admin
from .models import Customer
admin.site.register(Customer)
